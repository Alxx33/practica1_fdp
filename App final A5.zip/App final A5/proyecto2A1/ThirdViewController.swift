//
//  ThirdViewController.swift
//  proyecto2A1
//
//  Created by Alejandro Barron Solis, Isaac Hernandez Loredo.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit
import Firebase

class ThirdViewController: UIViewController{
    
    var ref: DatabaseReference!
   
    
    
 //   ref = Database.database().reference()
 

    
    @IBOutlet weak var Publicacion: UITextView!
    
    @IBOutlet weak var ImAgenda: UIImageView!
    
    @IBOutlet weak var ImCrono: UIImageView!
    
    @IBOutlet weak var ImEventos: UIImageView!
    
    @IBOutlet weak var ImUbicaciòn: UIImageView!
    

    
    var x = [menu] ()
    var sobrantes = ["Eventos"]
    var campo1 = String ()
    var campo2 = String ()
    var campo3 = String ()
    
    
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        x.append(menu(nombre: "Agenda",imagen:"", fecha: 0))
        x.append(menu(nombre: "Calendario",imagen:"", fecha: 0))
        ImAgenda.image = UIImage(named: "agenda")
        ImCrono.image = UIImage(named: "cronograma")
        ImUbicaciòn.image = UIImage(named: "ubicacion")
       

        if campo1 == "" {
            
            Publicacion.text = nil
            
        } else {
            
             Publicacion.text = "    De:   \(campo1) , asunto: \(campo2)  fecha: \(campo3) "
            
        }

     

}

   
    }

