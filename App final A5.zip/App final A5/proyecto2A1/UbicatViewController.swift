//
//  UbicatViewController.swift
//  proyecto2A1
//
//  Created by MacBook on 12/3/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class UbicatViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    
    @IBOutlet var mapa: MKMapView!
    let location = CLLocationManager()
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        mapa.delegate = self
        location.delegate = self
        
        location.requestAlwaysAuthorization()
        
        location.desiredAccuracy = kCLLocationAccuracyBest
        location.distanceFilter = kCLDistanceFilterNone
        
        location.startUpdatingLocation()
        mapa.showsUserLocation = true

        // Do any additional setup after loading the view.
    }
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let region = MKCoordinateRegion(center: mapa.userLocation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.009, longitudeDelta: 0.009))
        
        mapa.setRegion(region, animated: true)
    }
    
}
