//
//  SelectViewController.swift
//  proyecto2A1
//
//  Created by Macbook on 11/9/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit

class SelectViewController: UIViewController {
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

    }



}
