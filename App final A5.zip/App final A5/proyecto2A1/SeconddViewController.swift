//
//  SeconddViewController.swift
//  proyecto2A1
//
//  Created by Alejandro Barron Solis, Isaac Hernandez Loredo.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit
import Firebase


class SeconddViewController: UIViewController {
    
    var lista : [String] = []

    
    @IBOutlet weak var etiqueta: UILabel!
    @IBOutlet weak var use: UITextField!
    @IBOutlet weak var pass1: UITextField!
    @IBOutlet weak var pass2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }
    
    
    @IBAction func registrar(_ sender: UIButton) {
        
       
        if pass1.text == pass2.text {
            
            guard let usuario = use.text,
                let pass = pass2.text
             else  { return }
            
        
        print(usuario)
        
        Auth.auth().createUser(withEmail: usuario, password: pass) { (data,error) in
            
            if let error = error {
                debugPrint(error.localizedDescription)
            }
            
            let user = data?.user
            let changeRequest = user?.createProfileChangeRequest()
            changeRequest?.displayName = usuario
            changeRequest?.commitChanges(completion: {(error) in
                if let error2 = error {
                    debugPrint(error2.localizedDescription)
                }
            })
            
            guard let userId = user?.uid else {
                return }
            
            //Firestore.firestore().collection("users").document(userId).setData()
            
         Firestore.firestore().collection("users").document(userId).setData (["usuario": usuario, "date_creater": FieldValue.serverTimestamp()], completion:  { (error) in
                
                
                if let error3 = error {
                    debugPrint(error3)
                } else {
                    self.navigationController?.popViewController(animated: true)
                }
            
            } )
            
            
        }
    
        
        
        lista.append(use.text!)
 //       print (lista)
      
        
        if pass1.text == pass2.text {
            lista.append(pass2.text!)
//            print(lista)
            etiqueta.text = "¡Ya tienes cuenta!"
        }
        else{
            
            etiqueta.text = "¡Checa tu contraseña por favor!"
        }
        }
        
    }
    
    override func prepare (for segue: UIStoryboardSegue, sender: Any?) {
      
        let DestViewController : ViewController = segue.destination as! ViewController
        
        DestViewController.texto = use.text!
        
        if pass1.text == pass2.text {
       
            DestViewController.pass = pass2.text!
        
        }
      }
    }
    

